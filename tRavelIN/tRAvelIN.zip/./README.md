# tRAvelIN

ローカルの Docker 環境で動作確認するための手順をまとめています。必要に応じて README を参照すれば、新規メンバーでも同じ手順を踏めます。

## 事前準備

1. [Docker Desktop](https://www.docker.com/products/docker-desktop/) をインストールし、PowerShell で `docker compose` が利用できる状態にする。
2. `.env.example` をコピーして `.env` を作成し、以下の環境変数を設定する（値はローカル管理でリポジトリにコミットしない）。
	- `DB_HOST`, `DB_NAME`, `DB_PASSWORD`
	- `GEMINI_API_KEY`
	- `NODESERVER_HOST`, `PYTHONSERVER_HOST`

## 起動方法

```powershell
cd tRAvelIN
docker compose up --build
```

- 初回起動時は `config/seeds/seed.sql` が自動で流し込まれるまで待機します。
- `mysql`, `node-server`, `python-server`, `nginx` の各コンテナで “healthy” や “ready” が表示されたら完了です。
- ブラウザで `http://localhost/` にアクセスするとアプリを利用できます（Nginx が 80 番ポートを公開、Node が 3000 番、Python API が 5000 番で待機）。

## 終了方法

実行中のターミナルで `Ctrl+C` で停止後、必要に応じて以下を実行してください。

```powershell
docker compose down          # 通常の停止
docker compose down -v       # MySQL ボリュームも削除したい場合
```

README の手順に差分が出た場合は、最新の起動フローに合わせてこのセクションを更新してください。
