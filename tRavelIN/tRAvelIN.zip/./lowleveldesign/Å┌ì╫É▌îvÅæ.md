# 詳細設計書（tRAvelIN）

## 1. 文書情報
### 1.1 目的
- 本書は tRAvelIN の設計背景・システム構成・画面/API/DB の詳細仕様をまとめ、開発・テスト・運用メンバー間で共通理解を得ることを目的とする。

### 1.2 前提
- `docker compose up --build` で 4 コンテナが起動する現行リポジトリ (`main` ブランチ) を基準とする。
- 画面は `src/node-server/public` 配下の HTML/JS/CSS を前提とし、API は `src/node-server/server.mjs`, `src/python-server/app.py` の実装を対象とする。

## 2. アーキテクチャ設計
### 2.1 構成概要
```
┌──────────┐   HTTP/80    ┌────────────────┐
│ Browser   │────────────▶│ Nginx container │
└──────────┘              │  / → Node       │
													 │  /flask → Flask │
													 └────────┬───────┘
																		 │proxy
										 ┌───────────────┴──────────────┐
										 ▼                              ▼
						┌────────────────┐              ┌────────────────┐
						│ Node.js Express│◀─MySQL TCP──▶│   MySQL 8.0    │
						│ (port 3000)    │              │ (3306, seed付) │
						└────────────────┘              └────────────────┘
										 │REST (http)
										 ▼
						┌────────────────┐
						│ Flask (port5000)│
						│ + Gemini API    │
						└────────────────┘
```

### 2.2 ネットワーク/ポート
| コンテナ | ポート | 役割 |
| --- | --- | --- |
| nginx | 80/tcp (host公開) | ルーティング、静的ファイルキャッシュ |
| node-server | 3000/tcp (backend NW 内部公開) | フロント配信 + REST API |
| python-server | 5000/tcp (backend NW 内部公開) | AI スケジューラ |
| mysql | 3306/tcp (backend NW 内部公開) | データ永続化 |

### 2.3 起動順序
1. MySQL がヘルスチェック `mysqladmin ping` に応答できるまで待機。
2. Node.js が最大10回リトライしながら DB 接続確立。
3. Python サーバーが `NODESERVER_HOST` を使って Node API に接続。
4. Nginx が /, /flask を各サーバーにプロキシして完了。

## 3. フロントエンド詳細
### 3.1 画面一覧
| ファイル | 用途 | 主なイベント |
| --- | --- | --- |
| `public/travel_input_index.html` | 旅行情報入力フォーム | アコーディオンUI、Flatpickr、郵便番号補完、`plan-button` クリック |
| `public/schedule.html` | 生成スケジュール表示/編集 | タブ切替（晴/雨）、タイトル編集、保存ボタン |

### 3.2 旅行情報入力画面
- **コンポーネント**
	- ヘッダー：ロゴ、ログイン/新規登録モーダル。
	- 出発地：`yubinbango.js` による郵便番号→住所補完。完成住所は `startingPoint` 文字列に連結。
	- 旅行先：47都道府県＋市区町村データを JavaScript 配列で保持し、チェックボックスで複数選択。
	- 旅行期間：Flatpickr の range モードをインライン表示、選択結果を `start_day` / `last_day` に反映。
	- 同行者：年齢/性別/ペット別カウンタ。`updatePeopleGenderButton` でボタンラベルへ反映。
	- 予算：1000/1万/10万円単位のカウンタ。最低 5,000円になるよう制御し、合計を `plan-button` 送信時に集計。
	- ジャンル・こだわり：チェックボックス＋フリーテキスト。
- **バリデーション**
	- ログイン済み (`localStorage.user_id`) 必須。
	- 出発地は郵便番号または住所部品のいずれかが入力されていること。
	- 旅行期間は開始/終了を選択していない場合 `alert` で中断。
- **通信処理**
	1. `/save-schedule` → Node → MySQL `Tentative_schedule`、レスポンスで `tentative_id` を取得。
	2. `/save-companions` → `travel_companion` へ同行者情報保存。
	3. `/flask` → Nginx → Flask `POST /`。成功時に `localStorage.generatedSchedule` を設定し `schedule.html` へ遷移。

### 3.3 スケジュール表示画面
- 晴 (`#sunny`) と雨 (`#rain`) をラジオボタンタブで切替。
- `sunny.js` / `rain.js` が `localStorage.generatedSchedule` を読み込み、weather 種別ごとに DOM を整形。
- `title.js` がタイトル編集欄を提供。
- `saveSchedule.js` の責務
	- 編集モード切替 (`#edit-toggle`) で input[type=text] `.input` を有効化。
	- 晴/雨の保存ボタン押下で活動行の入力値を JSON に戻し、`localStorage.existingScheduleId` の有無で INSERT/UPDATE を切替。
	- 成功時は schedule_id を localStorage に保持し、再編集時に UPDATE を使用。

### 3.4 ローカルストレージキー
| キー | 用途 |
| --- | --- |
| `user_id` | ログイン後のユーザー識別。未設定なら `plan-button` を拒否。 |
| `generatedSchedule` | Gemini 応答（JSON文字列）。スケジュール画面で展開。 |
| `existingScheduleId` | 確定済みスケジュールの DB ID。保存ボタンで CRUD を切替。 |

### 3.5 JavaScript コンポーネント構成
| ファイル | 役割 | 入力/状態 | 出力/副作用 | 依存関係 |
| --- | --- | --- | --- | --- |
| `travel_input_script.js` | アコーディオン UI、人数/予算カウンタ、Flatpickr、API 呼び出しを統合するフロントエンド BFF | DOM、`localStorage.user_id`、都道府県データ配列 | `/save-schedule`, `/save-companions`, `/flask` へのリクエスト、`localStorage.generatedSchedule`、画面遷移 | Flatpickr, yubinbango.js, Fetch API |
| `title.js` | スケジュールタイトル入力の制御 | `localStorage.generatedSchedule` | `#title-input` を初期化 | DOM API |
| `sunny.js` / `rain.js` | 晴天/雨天タブのテーブル描画 | `localStorage.generatedSchedule`、`weather` フィルタ | DOM ノード（input.text）を動的生成、ID 体系（`time_<dayIdx>_<rowIdx>` 等）を付番 | `JSON.parse`, DocumentFragment |
| `saveSchedule.js` | 編集モード制御と確定スケジュール保存 | DOM input 値、`localStorage.user_id`, `localStorage.existingScheduleId`, `localStorage.generatedSchedule` | `/save-confirmed-schedule` or `/update-confirmed-schedule` 呼び出し、`localStorage.existingScheduleId` 更新 | Fetch API, confirm/alert |
| `rain.js` / `sunny.js` が生成した input 群 | 各レコードの `time/location/activity/url` | 画面編集後の値 | `saveSchedule.js` 内で JSON へ反映 | なし（構成要素） |

- **状態管理ポリシー**
	- 長期保持が必要な値はローカルストレージ（ユーザー ID、生成済みスケジュール ID、Gemini 応答）で管理し、ページリロードでも参照可能にする。
	- 一時的な UI 状態（編集中フラグ、ローディング表示など）は各スクリプト内の関数スコープ変数で管理し、再描画時に初期化する。
	- DOM ID 規約 `(<フィールド名>)_(1000 + dayIndex)_(rowIndex)` により `saveSchedule.js` が対象行を逆引きできるようにする。

### 3.6 UI コンポーネント相互作用
```
plan-button
	│ gathers form values (accordion, counters)
	├─▶ save-schedule API (tentative)
	├─▶ save-companions API
	└─▶ /flask → Gemini → localStorage.generatedSchedule

schedule.html
	│ reads generatedSchedule
	├─▶ sunny.js / rain.js render inputs
	├─▶ title.js init title-input
	└─▶ saveSchedule.js toggles edit + persist confirmed schedule
```
- フロントエンドは「入力画面」「結果画面」の 2 画面で完結し、それぞれが独立したスクリプト群を持つ。画面間の橋渡しはローカルストレージのみで行い、URL パラメータを使用しない設計とする。
- モーダル（ログイン/登録）は `travel_input_index.html` 内で `id` ベースの単純制御を行う。フェーズ次第で React/Vue などへ置き換える場合も、API 契約は踏襲可能。

## 4. サーバーサイド詳細
### 4.1 Node.js (server.mjs)
- **共通設定**
	- `express`, `body-parser`, `cors`, `bcryptjs`, `mysql` を使用。
	- DB 接続は `db.mjs` の `createConnection()` を通じて生成し、失敗時はリトライ。
	- 静的ファイルは `public` ディレクトリをルートに提供。

- **API一覧**
| メソッド/パス | 入力 | 処理 | 主なレスポンス |
| --- | --- | --- | --- |
| POST `/api/schedule` | 任意 JSON | Node から Flask (`PYTHONSERVER_HOST/api/schedule`) へプロキシ<br>※現状フロントでは未使用 | Flask のレスポンスを透過返却 |
| POST `/register` | `{ username, password }` | bcrypt(10) でハッシュ化し `User_master` へ INSERT | 200 OK / 500 | 
| POST `/login` | `{ username, password }` | `User_master` 参照 → bcrypt.compare | 成功: `{ success:true, user_id }`
| POST `/save-schedule` | 旅行条件一式 | `Tentative_schedule` に INSERT | `{ success:true, tentative_id }`
| POST `/save-companions` | 同行者情報 | `travel_companion` に INSERT | `{ success:true }`
| POST `/tentative-schedule` | `{ tentative_id }` | Tentative_schedule を SELECT  | `[ {...} ]`
| POST `/travel-companions` | `{ tentative_id }` | travel_companion を SELECT | `[ {...} ]`
| POST `/save-confirmed-schedule` | `{ user_id, json_text }` | Confirmed_schedule へ INSERT | `{ success:true, schedule_id }`
| POST `/get-confirmed-schedules` | `{ user_id }` | Confirmed_schedule 一覧取得 | `{ success:true, schedules:[...] }`
| POST `/update-confirmed-schedule` | `{ schedule_id, user_id, json_text }` | 対象レコードを UPDATE | `{ success:true }` or 404 |

- **例外処理方針**
	- SQL 実行エラー時は `console.error` とともに 500/JSON メッセージを返す。
	- バリデーション不足時は 400/401 で明示。

### 4.2 Flask (app.py)
- ルート `/` の POST のみを公開。`tentative_id` を受け取り以下を実行。
	1. `requests.post(NODESERVER_HOST + '/tentative-schedule')` で一時スケジュール取得。
	2. `requests.post(... '/travel-companions')` で同行者取得。
	3. `questionBuilder.build_question()` で Gemini へのプロンプトを生成。
	4. `geminiClient.generate_content()` → JSON 文字列が返る前提で `schedule` として返却。
- エラー時は `HTTPリクエストエラー` や Exception メッセージを JSON で返す。
- ※ Node の `/api/schedule` への直接経路も実装済みだが、現状 UI は Nginx `/flask` → Flask 直結を利用している。将来的に統一する場合はルーティングを整理すること。

### 4.3 Nginx
- `location /` → Node (静的ファイル/REST)。
- `location /flask` → Flask。`proxy_pass http://python_backend/;` によりパスを維持したまま転送。
	- `POST /flask` が Flask `/` に届く点に注意。Flask 側で `/api/schedule` を増やした場合は Nginx も合わせて調整する。

### 4.4 Node.js コンポーネント分割
| コンポーネント | 実装ファイル | 主責務 | 主な関数/ルート | 依存 | 備考 |
| --- | --- | --- | --- | --- | --- |
| HTTP サーバー | `server.mjs` | Express アプリ起動、ミドルウェア登録、API ルーティング | `app.post(...)`, `app.listen` | express, body-parser, cors | 静的ファイル提供と API を単一プロセスで兼任 |
| 認証サービス | `server.mjs` ( `/register`, `/login` ) | パスワードハッシュ化、比較 | `bcrypt.hash`, `bcrypt.compare` | bcryptjs, mysql | セッション Cookie を使わずレスポンス JSON の user_id をフロントが保持 |
| スケジュールドラフトサービス | `server.mjs` (`/save-schedule`, `/tentative-schedule`) | Tentative_schedule CRUD (Create/Read) | SQL INSERT/SELECT | mysql | バリデーション後に占有 |
| 同行者サービス | `/save-companions`, `/travel-companions` | travel_companion CRUD | SQL INSERT/SELECT | mysql | tentative_id をキーに一意 |
| 確定スケジュールサービス | `/save-confirmed-schedule`, `/update-confirmed-schedule`, `/get-confirmed-schedules` | Confirmed_schedule 永続化 | SQL INSERT/UPDATE/SELECT | mysql | json_text を長文で保存 |
| AI 連携プロキシ | `/api/schedule` | Node 経由で Flask に投げる経路（将来拡張用） | `fetch(FLASK_BASE_URL + '/api/schedule')` | node-fetch (ネイティブ fetch) | 現状 UI では未使用 |
| DB 接続ファクトリ | `db.mjs` | MySQL 接続生成 | `createConnection()` | mysql | 環境変数読み込み。再接続は server.mjs 側で制御 |

### 4.5 Flask コンポーネント分割
| コンポーネント | 実装 | 主責務 | 入出力 | 備考 |
| --- | --- | --- | --- | --- |
| ルーター層 | `app.py` (`@app.route('/')`) | tentative_id の受付、例外ハンドリング | IN: `{ tentative_id }` / OUT: `{ success, schedule }` | 今後 `/health` 等を追加する余地あり |
| Node API クライアント | `app.py` 内 `requests.post(...)` | Tentative/companion データ取得 | `NODESERVER_HOST` を `.env` で指定 | 失敗時は `requests.RequestException` を捕捉 |
| プロンプトビルダー | `questionBuilder.py` | Gemini への質問文生成 | IN: schedule_data(list), companion_data(list) | 旅行条件を自然言語へ変換 |
| LLM クライアント | `geminiClient.py` | Gemini API 呼び出し | IN: question(str) / OUT: text(str) | `google-generativeai`, `dotenv` |
| 表示ユーティリティ | `utils.py` | LLM 応答デバッグ出力 (Markdown) | コンソール出力のみ | 本番ログ用途は未定 |

### 4.6 API I/O 詳細
| API | リクエスト JSON | 成功レスポンス例 | エラーコード | 備考 |
| --- | --- | --- | --- | --- |
| `/register` | `{ "username": "alice", "password": "plain" }` | `200 text/plain` | 400: 入力不足<br>500: DBエラー | username 重複時は MySQL エラーを 500 で送出（要改善余地） |
| `/login` | `{ "username": "alice", "password": "plain" }` | `{ "success": true, "user_id": 3 }` | 400/401/500 | 401 は認証失敗 |
| `/save-schedule` | `{ user_id, travel_area_prefectures, ... }` | `{ "success": true, "tentative_id": 12 }` | 400/500 | 日付は ISO 文字列。Node 側で型変換せず保存 |
| `/save-companions` | `{ tentative_id, adultmale, ... }` | `{ "success": true }` | 400/500 | tentative_id が必須 |
| `/tentative-schedule` | `{ "tentative_id": 12 }` | `[ { ... } ]` | 400/500 | 未存在 ID の場合は空配列 |
| `/save-confirmed-schedule` | `{ user_id, json_text }` | `{ "success": true, "schedule_id": 5 }` | 400/500 | json_text はスケジュール全体（晴雨含む） |
| `/update-confirmed-schedule` | `{ schedule_id, user_id, json_text }` | `{ "success": true }` | 400/404/500 | user_id と schedule_id の複合条件で更新 |
| Flask `/` | `{ "tentative_id": 12 }` | `{ "success": true, "schedule": "{...json...}" }` | 400/404/500 | schedule フィールドは JSON 文字列。Node 側でダブル parse |

### 4.7 LLM プロンプト設計
- 実装場所: [src/python-server/questionBuilder.py](src/python-server/questionBuilder.py)
- 目的: Tentative_schedule / travel_companion の情報を自然言語に変換し、Gemini に晴天/悪天候の 2 系列スケジュール生成を指示する。

#### 4.7.1 プロンプト構成
| セクション | 内容 | 生成ロジック |
| --- | --- | --- |
| 冒頭ロール定義 | 「あなたは敏腕の旅行プランナーです…」 | 固定テキスト。LLM の役割付与。 |
| 制約1 | 晴天/悪天候双方のスケジュールを作成し、目的地を近接させる | 固定テキスト。天候切替を明示。 |
| 旅行条件挿入 | 出発地、旅行エリア、日付、予算、目的、同行者構成、こだわり | `schedule_data[0]`, `companion_data[0]` から文字列結合。日付は `YYYY-MM-DDTHH:MM:SS` → `split("T")[0]` で日付部分のみ使用。 |
| 出力形式指示 | JSON 例（title/days/weather/schedule） | 固定テンプレ。全 location に公式サイト URL を求める。 |
| 注意書き | 「余計な文章は出力しない」 | 固定。パース容易性確保。 |

#### 4.7.2 出力 JSON スキーマ（期待値）
```json
{
	"title": "○○旅行スケジュール",
	"days": [
		{
			"date": "1日目(10月11日)",
			"weather": "sunny",
			"schedule": [
				{ "time": "09:00", "activity": "△△駅到着", "location": "△△駅", "url": "https://..." }
			]
		},
		{
			"date": "1日目(10月11日)",
			"weather": "rainy",
			"schedule": [
				{ "time": "09:00", "activity": "△△駅到着", "location": "△△駅", "url": "https://..." }
			]
		}
	]
}
```
- weather 値は `sunny` / `rainy` のみを想定。日数分 × 2 エントリを持つ。
- URL は各 location の公式サイトと定義し、LLM に具体的な施設名+URL を生成させる。

#### 4.7.3 プロンプト例（入力データを反映）
```
あなたは敏腕の旅行プランナーです。以下の条件に基づいて最適な旅行スケジュールを立ててください。

1.晴天時の屋外中心の旅行スケジュールと悪天候時の屋内中心の旅行スケジュールの二つを作成する...(中略)
3.旅行の開始地点は東京都千代田区丸の内1-1-1、旅行の目的地は東京都内...
旅行の開始日は2025-03-20、旅行の終了日は2025-03-21、旅行の予算は50000円...
旅行に同行する人数は16歳以上の男性が2人...ペットが0匹...
全てのlocationでは詳細な店名、施設名を出す...
5.出力の形式は以下のjsonの形式に合わせる...
{
		"title": "〇〇旅行スケジュール",
		"days": [
			{
				"date": "1日目(x月y日)",
				"weather": "sunny",
				"schedule": [ ... ]
			},
			{
				"date": "1日目(x月y日)",
				"weather": "rainy",
				"schedule": [ ... ]
			}
		]
}
```

#### 4.7.4 変換/パース上の注意
- Gemini からの応答はテキスト。`localStorage` では一旦文字列として `JSON.stringify(response)` を保持しており、`schedule.html` 側で `JSON.parse(JSON.parse(schedule))` の 2 回パースを実施している。
- 今後の堅牢化では `try/catch` とスキーマ検証（Ajv など）を導入し、必須キー欠落時のフォールバック（再リクエストやユーザー通知）を検討する。

## 5. データベース設計
### 5.1 ER 概要
```
User_master 1 ── n Tentative_schedule 1 ── 1 travel_companion
	│                              └─ n Confirmed_schedule
```
- `tentative_schedule` と `travel_companion` は 1:1（同行者情報は一時スケジュールと同じライフサイクル）。
- `Confirmed_schedule` はユーザー単位で複数保存でき、`localStorage.existingScheduleId` により最新を追跡する。

### 5.2 テーブル物理定義
| テーブル | カラム (型) | 制約/備考 |
| --- | --- | --- |
| `User_master` | `user_id` INT UNSIGNED AUTO_INCREMENT`, `name` VARCHAR(64)`, `password` VARCHAR(255)` | PK: user_id, UNIQUE(name)。bcrypt 60 桁を想定し余裕を持たせる。 |
| `Tentative_schedule` | `tentative_id` INT AUTO_INCREMENT`, `user_id` INT`, `travel_area_prefectures` TEXT`, `travel_area` TEXT`, `start_day` DATETIME`, `last_day` DATETIME`, `budget` INT`, `purpose` TEXT`, `others` TEXT`, `starting_point` TEXT` | PK: tentative_id, FK(user_id) → User_master。
| `travel_companion` | `companion_id` INT AUTO_INCREMENT`, `tentative_id` INT`, `adultmale` INT`, `adultfemale` INT`, `boy` INT`, `girl` INT`, `infant` INT`, `pet` INT` | PK: companion_id, UNIQUE(tentative_id) で 1:1 を担保。
| `Confirmed_schedule` | `schedule_id` INT AUTO_INCREMENT`, `user_id` INT`, `json_text` LONGTEXT`, `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP`, `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP` | PK: schedule_id, FK(user_id) → User_master。

### 5.3 インデックス/制約方針
- `Tentative_schedule.user_id`、`Confirmed_schedule.user_id` に通常インデックスを付与し、ユーザー単位の検索を高速化する。
- `travel_companion.tentative_id` に UNIQUE インデックスを付け、意図しない複数レコードを防ぐ。
- 予算や日付を条件にした検索は現状 UI で行わないため二次インデックスは不要。ただし将来的に履歴検索を実装する場合は `start_day`, `last_day` への複合インデックスを検討する。

### 5.4 データライフサイクル
| ステップ | 発生イベント | 永続化対象 | 削除/更新タイミング |
| --- | --- | --- | --- |
| Tentative 作成 | フォーム送信直後 | Tentative_schedule, travel_companion | AI 生成に失敗しても残るため、一定期間でクリーンアップするバッチを別途検討。 |
| Gemini 生成成功 | Flask 応答を受領 | なし（ローカルストレージ保持） | `generatedSchedule` は schedule 保存後も残る。ユーザー操作で上書き。 |
| 確定保存 | schedule.html で保存ボタン | Confirmed_schedule | 更新時は `updated_at` が自動更新され履歴が残る。 |
| ユーザー削除 | 未実装 | 手動で User_master を消す場合は CASCADE を定義し関連レコード削除を一括化する。 |


## 6. シーケンス
### 6.1 プラン生成フロー
1. ユーザー入力完了後 `plan-button` クリック。
2. Node `/save-schedule` → `tentative_id` 返却。
3. Node `/save-companions` → 成功レスポンス。
4. フロント `/flask` (body: `{ tentative_id }`)。
5. Flask → Node `/tentative-schedule`, `/travel-companions`。
6. Flask → Gemini API (`google-generativeai`)。
7. Flask 応答 `{ success:true, schedule: <JSON文字列> }`。
8. フロントで `localStorage.generatedSchedule` 設定 → `schedule.html` へ遷移。

### 6.2 スケジュール確定フロー
1. `schedule.html` の編集モードで内容修正。
2. 「晴れ/雨予定の内容を保存」ボタン押下。
3. `saveSchedule.js` がローカル JSON を再構築。
4. `existingScheduleId` 無し: `/save-confirmed-schedule` を呼び出し、レスポンスの `schedule_id` を localStorage に保存。
5. 既存 ID 有り: `/update-confirmed-schedule` により上書き。成功時はメッセージログのみ。

## 7. 環境・設定ファイル
- `.env`（`.env.example` ベース）で DB・APIキー・ホスト名を定義。
- `config/seeds/seed.sql` で初期データを投入（ユーザーやサンプルスケジュール）。
- `config/nginx.conf` はローカル開発向けシンプル構成。HTTPS 化する際は証明書設定を追加する。
- Python 側は `python-server/requirements.txt` を `pip install -r` で導入。Gemini API 用キーは `password.env`（.gitignore 対象）から読み込む実装になっている。

## 8. エラーハンドリング / ログ
- Node: DB エラー時に `console.error` を記録し、API は 500/JSON（`success:false`）を返却。
- Flask: `requests` 例外と一般例外を区別し、クライアントに 500 を返す。
- フロント: API 失敗時は `alert()` で通知し、ローディングオーバーレイを閉じる。
- 重要ログ（ユーザー入力データ、Gemini 応答）はブラウザ `localStorage` に残るため、削除処理を UX 上どこで行うか要検討。

## 9. テスト観点（抜粋）
- **ユースケース**: 新規登録→ログイン→旅行情報入力→AI生成→編集→保存の一連フロー。
- **バリデーション**: 必須項目未入力、予算下限、ログイン未済時のガード。
- **API異常**: MySQL 停止時の再接続挙動、Gemini API 失敗時のユーザー通知。
- **ブラウザ互換性**: Chrome/Edge 最新、モバイル Safari でのアコーディオン/Flatpickr 動作。
- **セキュリティ**: SQL インジェクション耐性、パスワードハッシュ確認、CORS 設定の再確認。

## 10. 設計上のメモ
- Node `/api/schedule` は現在の UI からは呼ばれておらず、将来的なプロキシ用途として残っている。ルーティング統一を検討すること。
- Gemini から返る文字列は JSON として `JSON.parse(JSON.parse(...))` を行っているため、失敗時に備えたスキーマバリデーション（例: `Ajv`）の導入を推奨。
- `localStorage` に保存される個人情報（住所等）はセキュリティ観点で最小限に抑えるか、セッション完了時に削除する改善余地がある。

