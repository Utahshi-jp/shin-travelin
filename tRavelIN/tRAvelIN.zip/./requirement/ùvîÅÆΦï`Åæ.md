# 要件定義書（tRAvelIN）

## 1. 概要
### 1.1 システム名
- **正式名称**: tRAvelIN（悪天候対応型 旅行スケジュール自動生成アプリ）

### 1.2 システム概要
- ユーザーが希望する出発地・旅行先・日程・同行者・予算・目的（飲食/観光/アクティビティ/イベント）などを入力すると、晴天・悪天候の両方に対応した旅行スケジュール案を自動生成する。 
- 生成されたスケジュールはブラウザ上で編集し、確定スケジュールとして保存できる。
- アプリは Docker 上で `nginx → Node.js → MySQL` と `nginx → Python(Flask) → Gemini API` の2系統で構成され、`Nginx` がルーティングを担う。

### 1.3 目標
- 突発的な天候変化でも旅行が継続できるよう、天候に応じた複数プランを数分以内に提示すること。
- ノンプログラマーが Docker コンテナを起動するだけで環境構築できること。
- 個人旅行～小規模グループ旅行程度（最大大人6名＋子ども4名＋幼児2名＋ペット2匹を想定）の要望をカバーすること。

## 2. 背景と課題
- 旅行計画では天候によるリスクが大きく、現地でのアクティビティが中止になるケースが多い。
- 既存の旅行プランニングサービスは天候別プランを自動生成するものが少なく、手動で代替案を準備する必要がある。
- 旅行会社に相談するほどの予算規模でない個人旅行でも、信頼できる代替プランを短時間で得たいという需要がある。

## 3. ステークホルダー
| 区分 | 役割 | 主な関心事 |
| --- | --- | --- |
| エンドユーザー | 旅行計画利用者 | 直感的に入力し、現実的なスケジュールをすぐ入手したい |
| 企画担当 | サービス企画/要件策定 | ターゲット価値の最大化、追加機能の企画 |
| 開発チーム | Node/Flask/フロント実装 | 品質/保守性/技術負債コントロール、Docker 運用 |
| インフラ担当 | Docker/Nginx/MySQL 運用 | 安定運用、認証情報管理、ログ監視 |
| 外部API提供者 | Google Gemini API | API コール数、キー管理、利用規約順守 |

## 4. 想定ユーザーと利用シナリオ
| ID | ペルソナ | シナリオ概要 |
| --- | --- | --- |
| U-01 | 首都圏在住の20代カップル | 週末2日の旅行を計画。天候別スケジュールを比較し、晴れなら屋外アクティビティ、雨なら屋内イベントへ切替える。
| U-02 | 小学生の子を持つ家族 | 夏休み4日間旅行。子ども向け施設と雨天時の屋内体験を事前に押さえたい。
| U-03 | 友人グループ | 予算上限を決めた上で飲食中心のプランを作り、編集したスケジュールを共有する。

## 5. スコープ
- **対象業務**: 旅行情報の収集、AIによる天候別スケジュール生成、スケジュールの閲覧/編集/保存。
- **非対象**: 交通・宿泊の予約実行、支払い処理、実世界の気象観測、マイページ共有機能。
- **前提条件**: ユーザーはログイン済みであること、Gemini APIキーが正しく設定されていること。

## 6. 業務フロー（As-Is → To-Be）
1. ユーザーが `http://localhost/` へアクセスすると、Nginx が Node.js の `public/travel_input_index.html` を返す。
2. 未登録の場合は `/register` API を通じてユーザーを作成し、ログイン後に `localStorage.user_id` を保持する。
3. フォームに出発地・旅行先（都道府県/市区町村）・期間・同行者・予算・ジャンル・こだわりを入力し、「プラン作成」を実行する。
4. Node.js が `/save-schedule` と `/save-companions` で MySQL の Tentative_schedule / travel_companion に入力値を保存する。
5. フロントエンドが `POST /flask` を呼び出し、Nginx 経由で Flask サーバーに `tentative_id` を渡す。
6. Flask が Node.js API `/tentative-schedule`, `/travel-companions` からデータを取得し、`questionBuilder` で Gemini 用プロンプトを生成する。
7. Gemini API から得た JSON スケジュールをブラウザに戻し、`localStorage.generatedSchedule` に保存して `schedule.html` へ遷移する。
8. スケジュール画面で晴れ/雨タブごとに編集し、`/save-confirmed-schedule` または `/update-confirmed-schedule` で確定版を保存する。

## 7. 機能要件
| ID | 機能名 | 説明 | 優先度 |
| --- | --- | --- | --- |
| F-01 | ユーザー登録 | `POST /register` でユーザー名・ハッシュ化パスワードを保存する。 | Must |
| F-02 | ログイン | `POST /login` で認証し、`user_id` を返却する。 | Must |
| F-03 | 旅行情報入力 | 出発地、旅行先、期間、同行者、予算、ジャンル、こだわりを UI で入力できる。 | Must |
| F-04 | 入力値の一時保存 | `Tentative_schedule`, `travel_companion` に保存し `tentative_id` を払い出す。 | Must |
| F-05 | AI スケジュール生成 | Flask → Gemini API を介して晴/雨スケジュールを JSON で生成する。 | Must |
| F-06 | スケジュール編集 | `schedule.html` 上でタイトル/各行程を編集し、天候別に保存する。 | Should |
| F-07 | 確定スケジュール保存 | `POST /save-confirmed-schedule` で JSON を `Confirmed_schedule` に永続化、`/update-confirmed-schedule` で更新。 | Must |
| F-08 | 既存プラン再利用 | `POST /get-confirmed-schedules` で履歴を取得し、再編集に利用する（UI 実装は今後）。 | Could |

## 8. データ要件
| テーブル | 主要カラム | 用途 |
| --- | --- | --- |
| `User_master` | `user_id`, `name`, `password`(bcrypt) | 認証情報。名前はユニーク。 |
| `Tentative_schedule` | `tentative_id`, `user_id`, `travel_area_prefectures`, `travel_area`, `start_day`, `last_day`, `budget`, `purpose`, `others`, `starting_point` | AI 生成前の生データ保持。 |
| `travel_companion` | `tentative_id`, `adultmale`, `adultfemale`, `boy`, `girl`, `infant`, `pet` | 同行者構成の記録。 |
| `Confirmed_schedule` | `schedule_id`, `user_id`, `json_text`, `created_at`, `updated_at`(想定) | 確定スケジュールの JSON 永続化。 |

## 9. 非機能要件
### 9.1 性能
- フォーム提出～スケジュール表示まで平均 8 秒以内（Gemini API の応答時間に依存）。
- 同時アクセス 20 ユーザーを想定。Docker コンテナで水平スケール可能な構成とする。

### 9.2 信頼性・可用性
- MySQL にはヘルスチェックを設定し、Node.js は最大10回リトライして接続する。
- 重大障害時は Docker 再起動だけで復旧できるようステートフルデータを `.data/mysql` ボリュームへ永続化する。

### 9.3 セキュリティ
- パスワードは `bcryptjs` でハッシュ化、APIキーは `.env` で管理しリポジトリに含めない。
- CORS 制御と HTTPS（本番）を前提。現在は開発環境向けに `cors()` をフル許可。
- SQL インジェクション対策としてプレースホルダを使用済み。

### 9.4 運用・保守
- docker compose コマンドのみで起動/停止可能。
- エラー発生時は各サーバーの標準出力ログを参照し、API レスポンスは JSON メッセージで返す。

### 9.5 UX
- PC/モバイルで表示崩れがないよう `responsive viewport` を設定済み。
- 入力必須項目は赤アスタリスクで明示し、バリデーション失敗時は `alert` で通知。

## 10. 外部インターフェース・環境要件
### 10.1 システム構成
- `docker-compose.yml` で node-server, python-server, mysql, nginx を定義。
- `nginx` が `location /` を Node.js、`location /flask` を Flask にプロキシ。

### 10.2 環境変数
| 変数 | 用途 |
| --- | --- |
| `DB_HOST`, `DB_NAME`, `DB_PASSWORD`, `DB_USER` | Node.js → MySQL 接続設定 |
| `NODESERVER_HOST`, `PYTHONSERVER_HOST` | サービス間通信 URL |
| `GEMINI_API_KEY`, `GEMINI_MODEL` | Gemini API 認証/モデル指定 |

### 10.3 外部API
- Google Gemini API（`google-generativeai` ライブラリ）
- 郵便番号 API（`yubinbango.js`）
- Flatpickr CDN

## 11. 受入基準
- 代表的なシナリオ（晴天/悪天候プラン生成、編集/保存）がエラーなく完了すること。
- 主要ブラウザ（Chrome 最新、Edge 最新）の最新 PC 環境で UI が崩れないこと。
- Docker Compose `up` 後、4コンテナが Healthy になり、`http://localhost/` でフォーム入力 → Gemini 応答まで完走できること。

